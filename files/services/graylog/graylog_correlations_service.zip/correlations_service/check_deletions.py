#!/usr/bin/env python3

import socket, time, json, ntpath, logging
from time import strftime, localtime
import argparse

from circular_dict import CircularDict
from pygelf import GelfTcpHandler

PROG_DESCRIPTION="Deleted files correlation:\ntries to correlate EventID 4660 with previous received EventID 4663 with Accesses DELETE"

# DEFAULTS
INCOMING_HOST = "127.0.0.1"
INCOMING_PORT = 12201
OUTGOING_HOST = "127.0.0.1"
OUTGOING_PORT = 9401
LAST_EVTS_MAXLEN = 30

# use logging to send events in GELF format to outgoing_host:outgoing_port
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

# parse command parameters
parser = argparse.ArgumentParser(
    prog="correlate_deletions",
    description=PROG_DESCRIPTION,
    allow_abbrev=True,
    formatter_class=argparse.ArgumentDefaultsHelpFormatter
)
parser.add_argument("-i", "--incoming-host", dest="Incoming_Host", 
                    help="IP Address to bind to receive events\n", default=INCOMING_HOST)
parser.add_argument("-p", "--incoming-port", dest="Incoming_Port", 
                    help="TCP Port to bind to receive events\n", default=INCOMING_PORT)
parser.add_argument("-o", "--outgoing-host", dest="Outgoing_Host",
                    help="IP Address to send correlated events to\n", default=OUTGOING_HOST)
parser.add_argument("-P", "--outgoing_port", dest="Outgoing_Port", 
                    help="TCP Port to send correlated events\n", default=OUTGOING_PORT)
parser.add_argument("-l", "--maxlen", dest="Last_evts_Maxlen",
                    help="Length of 4663 events store dict", default=LAST_EVTS_MAXLEN)
args = parser.parse_args()

def main():
    def process_event(event):
        #print('------RAW-------')
        #print(event)
        #print('------RAW-------')
        if event["_EventID"] == 4663:
            print(f'{event["_EventID"]} @ {event["_timestamp"]}: {event["_SubjectUserName"]}({event["_LogonID"]})\t{event["_HandleId"]}\t{event["_ObjectName"]}')

            filename = ntpath.basename(event["_ObjectName"])
            if (not filename.startswith('~$')) and (not filename.lower().endswith('.tmp')) and not (filename.lower().endswith('~')):
                last_wevts[event["_HandleId"]] = event

        elif event["_EventID"] == 4660 and event["_HandleId"] in last_wevts:
            print(f'{event["_EventID"]} @ {event["_timestamp"]}: {event["_SubjectUserName"]}({event["_LogonID"]})\t{event["_HandleId"]}')

            we_4663 = last_wevts[event["_HandleId"]]
            _timestamp = event["_timestamp"].replace("T", " ").replace("Z", " ")
            if event["timestamp"] == we_4663["timestamp"] and event["_LogonID"] == we_4663["_LogonID"]:
                objectName = we_4663["_ObjectName"]
                wevt_log = {}
                for k in we_4663:
                    if k.startswith('_'):
                        wevt_log[k[1:]] = we_4663[k]
                del(wevt_log["timestamp"])
                wevt_log["timestamp"] = _timestamp
                wevt_log["EventID"] = "104660" # fake eventid
                wevt_log["short_message"] = "An object was deleted."
                wevt_log["full_message"] = wevt_log["full_message"].replace("An attempt was made to access an object.", "An object was deleted.")
                wevt_log["version"] = "1.1"
                wevt_log["message"] = wevt_log["message"].replace("An attempt was made to access an object.", "An object was deleted.")
                logger.info(json.dumps(wevt_log))

                print(f'DELETED: {_timestamp}\t{event["_HandleId"]}\t{event["_SubjectUserName"]}\t{objectName}')
                print('----------------')
        else:
            print(f'{event["_EventID"]} @ {event["_timestamp"]}: {event["_SubjectUserName"]}({event["_LogonID"]})\t{event["_HandleId"]}')
            print('----------------')

    # use Gelf to send logs back to graylog2
    logger.addHandler(GelfTcpHandler(host=args.Outgoing_Host, port=int(args.Outgoing_Port)))
    # globals
    last_wevts = CircularDict(maxlen=int(args.Last_evts_Maxlen), include_extra_fields=True)

    # Creates and binds a socket to Incoming_Host:Incoming_Port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((args.Incoming_Host, int(args.Incoming_Port)))
        s.listen()
        conn, addr = s.accept()
        with conn:
            print(f"Connected by {addr}")

            # main loop
            while True:
                data = conn.recv(32768).decode()
                if not data:
                    break
                data = data.replace("'", "\"")
                try:
                   w_event = json.loads(data[:-1], strict=False)
                except json.decoder.JSONDecodeError as j:
                    try:
                        for d in data.split('\x00'):
                            process_event(d)
                    except:
                        pass
                else:
                   process_event(w_event)

if __name__ == '__main__':
    main()

