#!/bin/bash 
#
# 

# python requirements
pip3 install -r ./requirements.txt 2> /dev/null

# copy files
install -C -m 0644 -g root -o root correlations.service /etc/systemd/system/correlations.service
install -C -m 0755 -g root -o root check_deletions.py /usr/local/bin/check_deletions.py
install -C -m 0644 -g root -o root default_correlations /etc/default/correlations

# reload systemd
systemctl daemon-reload

if systemctl is-active --quiet correlation.service; then
   systemctl restart correlations.service
else
   systemctl enable --now correlations.service
fi

# install 'expect' so I can use unbuffer to show status (silly me)
. /etc/os-release
if [ "${ID_LIKE}" == "rhel centos fedora" ]; then
   dnf -qq -y install expect
elif [ "${ID_LIKE}" == "debian" ]; then
   apt-get -qq -y install expect
fi
# show status 
echo
unbuffer systemctl --no-pager status correlations.service | head -n 5
